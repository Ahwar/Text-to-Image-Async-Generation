import os
from celery import Celery

from kombu import Exchange, Queue

BROKER_URI = "amqp://localhost"
BACKEND_URI = "redis://localhost"

app = Celery(
    'celery_app',
    broker=BROKER_URI,
    backend=BACKEND_URI,
    include=['celery_task_app.tasks']
)
